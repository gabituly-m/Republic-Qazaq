

$(document).ready(function(){
  $('.fa-bars').click(function(){
    $(this).toggleClass('fa-times');
    $('.nav').toggleClass('nav-toggle');
  });

  $(window).on('load scroll',function(){

    $('.fa-bars').removeClass('fa-times');
    $('.nav').removeClass('nav-toggle');

    if($(window).scrollTop() > 10){
      $('header').addClass('header-active');
    }else{
      $('header').removeClass('header-active');
    }

  });

  $('.facility').magnificPopup({
    delegate:'a',
    type:'image',
    gallery:{
      enabled:true
    }
  });


});
var elems = document.querySelectorAll('ul li a ');

for (var i=0; i<elems.length; i++) {
    elems[i].style.color ='white';
}

function myMusic(){
 var btn = document.getElementById("btn")
 var mySong= document.getElementById("mySong");
 if (mySong.paused){
 btn = mySong.play();
}
else{
  mySong.pause();
}
}


function boxing(){
  document.getElementById('box1').style.transform = 'scale(1.1)';
  document.getElementById('box1').style.transition = '500ms';

}
function boxingOut(){
  document.getElementById('box1').style.transform = 'none';
}
function boxing2(){
  document.getElementById('box2').style.transform = 'scale(1.1)';
  document.getElementById('box2').style.transition = '500ms';
}
function boxingOut2(){
  document.getElementById('box2').style.transform = 'none';
}
function boxing3(){
  document.getElementById('box3').style.transform = 'scale(1.1)';
  document.getElementById('box3').style.transition = '500ms';
}
function boxingOut3(){
  document.getElementById('box3').style.transform = 'none';
}

// Get DOM Elements
const modal = document.querySelector('#my-modal');
const modalBtn = document.querySelector('#modal-btn');
const closeBtn = document.querySelector('.close');

// Events
modalBtn.addEventListener('click', openModal);
closeBtn.addEventListener('click', closeModal);
window.addEventListener('click', outsideClick);

// Open
function openModal() {
  modal.style.display = 'block';
}

// Close
function closeModal() {
  modal.style.display = 'none';
}

// Close If Outside Click
function outsideClick(e) {
  if (e.target == modal) {
  modal.style.display = 'none';
  }
}
